function pow(a, b) {
    return Math.pow(a, b);
}

function modulo(a, b) {
    return a % b;
}

module.exports = {
    pow,
    modulo
}